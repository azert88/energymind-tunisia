# EnergyMind - single-house anomaly detector (lightgbm)

Detects 13 anomaly types on ONE house from its smart-meter data and the transformer measurements.
The model weights are frozen in `model/model.txt` (lightgbm 4.7.0 native format, no pickle).

## Install
```
pip install -r requirements.txt
```

## Try it on the sample data
```
python predict.py --house-file sample_data/house_07.csv --transformer-file sample_data/transformer_house_07.csv --out result_house_07.csv
python predict.py --house-file sample_data/house_09.csv --transformer-file sample_data/transformer_house_09.csv --out result_house_09.csv
```
`house_07` has no PV; `house_09` has PV + battery. Compare the `anomalies` column with
`sample_data/<house>_true_labels.csv` (the true injected anomalies). Both periods come from the test set.

## Your own house
```
python predict.py --house-file my_house.csv --transformer-file my_trafo.csv --out result.csv --only-anomalies
```
| File | What it needs |
|---|---|
| my_house.csv | `timestamp`; `U_1..3`, `I_1..3`, `P_1..3`, `Q_1..3`, `S_1..3`, `PF_1..3`; `P_TOT`, `Q_TOT`, `S_TOT`, `PF_TOT`; `grid_available` (1/0); any number of `app_<name>_W` appliance columns. PV houses also: `P_PV_W`, `battery_soc_percent`, `battery_voltage_v`, `battery_current_a`, `battery_charge_power_w`, `battery_discharge_power_w`, `inverter_ac_output_w`, `inverter_status`, `transfer_switch_status` (GRID/BATTERY), `backup_mode_active`, `backup_load_demand_w`, `backup_load_served_w`, `unmet_backup_demand_w` |
| my_trafo.csv | `timestamp`, `transformer_loading_percent`, `transformer_P_kw`, `transformer_Q_kvar`, `transformer_U_pu`, `other_feeders_P_kw` |
| Time | one row every 15 min, same timestamps in both files, at least 7 days (first day less reliable) |

Units: V, A, W, var, VA; power factor 0-1; transformer P in kW, Q in kvar, voltage in per-unit (1.0 = 230.9 V);
`other_feeders_P_kw` = power of the transformer customers outside the monitored group.
Use `--pv-kwp` to give the PV size of a PV house (otherwise estimated from the data).

## Output (one row per 15 min)
`anomalies` ("normal" or up to two: "a|b"), `primary_anomaly`, `confidence`, `category`
(real event or sensor / data problem), `agent_action`, `needs_human`, and `p_<type>` for the 14 types.

## Test scores (simulated test set)
Macro F1 0.889 | detection precision 0.994, recall 0.969,
F1 0.981 | false-alarm runs per 100 house-days 5.4

| Anomaly | House type | F1 |
|---|---|---|
| localized_grid_outage | A+B | 1.00 |
| sustained_undervoltage | A+B | 1.00 |
| transformer_overload | A+B | 1.00 |
| battery_charge_failure | A | 0.88 |
| battery_discharge_failure | A | 0.85 |
| pv_partial_shading | A | not detected in this mode |
| meter_frozen | A+B | 1.00 |
| meter_dropout | A+B | 1.00 |
| meter_drift | A+B | 0.80 |
| meter_noise | A+B | 1.00 |
| meter_bias_current | A+B | 0.93 |
| voltage_sensor_fault | A+B | 1.00 |
| falsified_under_report | A+B | 0.99 |
| falsified_replay | A+B | 1.00 |

House type: A+B = all houses, A = PV + battery houses only.

## Limits
- Trained on simulated data (SimBench LV1.101, 2018). Real data will be noisier.
- Meter faults (under-reporting, bias, drift) are detected by comparing the meter with the sum of the
  `app_*_W` columns; without appliance data these types will be detected much less well.
- Disabled in this mode (cannot be separated on validation): pv_partial_shading.

## Files
| File | Content |
|---|---|
| `model/model.txt` | frozen model weights |
| `model/model_config.json` | feature order, decision thresholds, labels, versions, test scores |
| `labels.json` | category, suggested action and human decision for each anomaly type |
| `energymind_features.py` | feature engineering (must stay identical to training) |
| `predict.py` | the detector |
