"""EnergyMind - anomaly detector for ONE house (lightgbm model, frozen weights).

Usage:
    python predict.py --house-file my_house.csv --transformer-file my_trafo.csv [--out result.csv]
                      [--house-id house_07] [--pv-kwp 4.0] [--only-anomalies]

my_house.csv      : timestamp + meter channels (U/I/P/Q/S/PF per phase, P/Q/S/PF_TOT), grid_available,
                    app_*_W appliance columns, and PV/battery/inverter columns if the house has PV
my_trafo.csv      : timestamp, transformer_loading_percent, transformer_P_kw, transformer_Q_kvar,
                    transformer_U_pu, other_feeders_P_kw
Both files: one row every 15 minutes, the same timestamps, at least 7 days.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from energymind_features import build_single_house_features

HERE = Path(__file__).resolve().parent
CFG = json.loads((HERE / "model" / "model_config.json").read_text())
INFO = json.loads((HERE / "labels.json").read_text())
LABELS = CFG["labels"]
PRIORITY = {"battery_discharge_failure", "localized_grid_outage", "transformer_overload",
            "sustained_undervoltage", "falsified_replay"}


def load_model():
    import lightgbm as lgb
    return lgb.Booster(model_file=str(HERE / "model" / "model.txt"))


def predict_proba(model, F: pd.DataFrame) -> np.ndarray:
    X = F.reindex(columns=CFG["features"]).to_numpy(np.float32)     # missing PV columns -> NaN (grid-only house)
    P = model.predict(X)
    return P[:, 1:]                                                  # column 0 = normal


def combine(keys: pd.DataFrame, P: np.ndarray) -> pd.DataFrame:
    th = np.asarray(CFG["thresholds"])
    on_all = P >= th[None, :]
    out = keys.copy()
    labs, prim, conf, cat, act, hum = [], [], [], [], [], []
    for i in range(len(P)):
        on = np.where(on_all[i])[0]
        on = on[np.argsort(-P[i, on])][:2]
        if len(on) == 0:
            labs.append("normal"); prim.append("normal"); conf.append(float(1 - P[i].max())); cat.append("normal")
            act.append("none"); hum.append("")
            continue
        names = [LABELS[j] for j in on]
        labs.append("|".join(names)); prim.append(names[0]); conf.append(float(P[i, on[0]]))
        cat.append(" + ".join(sorted({INFO[n]["category_text"] for n in names})))
        if len(names) == 2 or P[i, on[0]] < 0.7:
            act.append("UNCLEAR CASE (two anomalies or low confidence): flag, log, notify -> human decides. "
                       + " / ".join(f"{n}: {INFO[n]['agent_action']}" for n in names))
        else:
            act.append(("[HIGH] " if names[0] in PRIORITY else "") + INFO[names[0]]["agent_action"])
        hum.append(" / ".join(INFO[n]["human_decision"] for n in names))
    out["anomalies"], out["n_anomalies"] = labs, on_all.sum(1).clip(max=2)
    out["primary_anomaly"], out["confidence"], out["category"] = prim, np.round(conf, 3), cat
    out["agent_action"], out["needs_human"] = act, hum
    for j, l in enumerate(LABELS):
        out[f"p_{l}"] = np.round(P[:, j], 4)
    return out


def read(p):
    p = Path(p)
    return pd.read_parquet(p) if p.suffix == ".parquet" else pd.read_csv(p, parse_dates=["timestamp"])


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--house-file", required=True)
    ap.add_argument("--transformer-file", required=True)
    ap.add_argument("--out", default="result.csv")
    ap.add_argument("--house-id", default=None, help="name used in the output (default: file name)")
    ap.add_argument("--pv-kwp", type=float, default=None, help="PV size; estimated from the data if not given")
    ap.add_argument("--only-anomalies", action="store_true")
    a = ap.parse_args()
    m, tm = read(a.house_file), read(a.transformer_file)
    hid = a.house_id or Path(a.house_file).stem
    F = build_single_house_features(m, tm, hid, pv_kwp=a.pv_kwp)
    res = combine(F[["timestamp", "house_id"]].reset_index(drop=True), predict_proba(load_model(), F))
    if a.only_anomalies:
        res = res[res.anomalies != "normal"]
    res.to_csv(a.out, index=False)
    n_an = int((res.anomalies != "normal").sum())
    print(f"model: {CFG['model']} | house: {hid} | {len(res)} rows written to {a.out}, {n_an} anomalous")
    if CFG.get("disabled_labels"):
        print("not detected in single-house mode:", ", ".join(CFG["disabled_labels"]))
    if n_an:
        print(res[res.anomalies != "normal"].groupby("anomalies").size().rename("steps (15 min)").to_string())


if __name__ == "__main__":
    main()
